import hashlib
import json
import os
import re
import time
import boto3
from botocore.exceptions import ClientError

sns = boto3.client("sns")
dynamodb = boto3.resource("dynamodb")
TOPIC_ARN = os.environ["SNS_TOPIC_ARN"]
RATE_LIMIT_TABLE = dynamodb.Table(os.environ["RATE_LIMIT_TABLE_NAME"])
RATE_LIMIT_MAX = int(os.environ.get("RATE_LIMIT_REQUESTS", "5"))
RATE_LIMIT_WINDOW = int(os.environ.get("RATE_LIMIT_WINDOW_SECONDS", "3600"))
EMAIL_RE = re.compile(r"^[^\s@]+@[^\s@]+\.[^\s@]+$")


def response(status_code, message):
    return {
        "statusCode": status_code,
        "headers": {"content-type": "application/json; charset=utf-8"},
        "body": json.dumps({"message": message}),
    }


def consume_rate_limit(source_ip):
    # Store a one-way hash rather than raw IP addresses.
    ip_hash = hashlib.sha256(source_ip.encode("utf-8")).hexdigest()
    now = int(time.time())
    cutoff = now - RATE_LIMIT_WINDOW
    values = {
        ":zero": 0,
        ":one": 1,
        ":now": now,
        ":cutoff": cutoff,
        ":expires": now + RATE_LIMIT_WINDOW * 2,
    }

    try:
        result = RATE_LIMIT_TABLE.update_item(
            Key={"ip_hash": ip_hash},
            UpdateExpression="SET #count = if_not_exists(#count, :zero) + :one, window_start = if_not_exists(window_start, :now), expires_at = :expires",
            ConditionExpression="attribute_not_exists(window_start) OR window_start > :cutoff",
            ExpressionAttributeNames={"#count": "request_count"},
            ExpressionAttributeValues=values,
            ReturnValues="UPDATED_NEW",
        )
    except ClientError as error:
        if error.response.get("Error", {}).get("Code") != "ConditionalCheckFailedException":
            raise
        # The previous window expired. Reset it atomically. If another request
        # wins this race, reject this request rather than risk bypassing the limit.
        try:
            result = RATE_LIMIT_TABLE.update_item(
                Key={"ip_hash": ip_hash},
                UpdateExpression="SET #count = :one, window_start = :now, expires_at = :expires",
                ConditionExpression="window_start <= :cutoff",
                ExpressionAttributeNames={"#count": "request_count"},
                ExpressionAttributeValues=values,
                ReturnValues="UPDATED_NEW",
            )
        except ClientError as reset_error:
            if reset_error.response.get("Error", {}).get("Code") == "ConditionalCheckFailedException":
                return False
            raise

    return int(result["Attributes"]["request_count"]) <= RATE_LIMIT_MAX


def handler(event, context):
    method = event.get("requestContext", {}).get("http", {}).get("method", "POST")
    if method != "POST":
        return response(405, "Method not allowed")

    headers = {str(k).lower(): v for k, v in (event.get("headers") or {}).items()}
    content_type = str(headers.get("content-type", "")).lower()
    if "application/json" not in content_type:
        return response(415, "Content-Type must be application/json")

    raw_body = event.get("body") or ""
    if event.get("isBase64Encoded"):
        return response(400, "Invalid request")
    if len(raw_body) > 12000:
        return response(413, "Message is too large")

    try:
        data = json.loads(raw_body)
    except (TypeError, json.JSONDecodeError):
        return response(400, "Invalid JSON")
    if not isinstance(data, dict):
        return response(400, "Invalid request")

    # Honeypot: bots that fill the hidden company field receive a generic success.
    if str(data.get("company", "")).strip():
        return response(200, "Your message has been received")

    source_ip = event.get("requestContext", {}).get("http", {}).get("sourceIp")
    if not source_ip:
        return response(400, "Unable to verify request source")

    name = str(data.get("name", "")).strip()
    email = str(data.get("email", "")).strip()
    message = str(data.get("message", "")).strip()

    if not name or len(name) > 100:
        return response(400, "Enter a name of 1 to 100 characters")
    if not email or len(email) > 254 or not EMAIL_RE.fullmatch(email):
        return response(400, "Enter a valid email address")
    if not message or len(message) > 5000:
        return response(400, "Enter a message of 1 to 5000 characters")

    # Reject excess submissions before SNS. Fail closed if rate-limit storage fails.
    try:
        allowed = consume_rate_limit(source_ip)
    except Exception:
        print("Rate-limit check failed; rejecting submission")
        return response(503, "Unable to submit right now. Please try again later.")
    if not allowed:
        return response(429, "Too many submissions. Please try again later.")

    # Keep the destination fixed. Never accept a recipient from user input.
    body = f"New contact form submission\n\nName: {name}\nEmail: {email}\n\nMessage:\n{message}"
    sns.publish(
        TopicArn=TOPIC_ARN,
        Subject="New website contact form submission",
        Message=body,
    )
    return response(200, "Your message has been received")
